"use client";

import { useState } from "react";
import { useTranslation } from "react-i18next";

import type { City } from "@/entities/city";
import type { CurrentLocation } from "@/entities/location";
import { LanguageSwitcher } from "@/features/change-language";
import { ThemeSwitcher } from "@/features/change-theme";
import { LocateUserButton } from "@/features/locate-user";
import { CitySearch } from "@/features/search-city";
import { useSelectedCity } from "@/features/select-city";
import { WeatherOverview } from "@/widgets/weather-overview";

type LocationSource = "city" | "browser";

export function HomePage() {
  const { t } = useTranslation();
  const { selectedCity, selectCity } =
    useSelectedCity();

  const [currentLocation, setCurrentLocation] =
    useState<CurrentLocation | null>(null);

  const [locationSource, setLocationSource] =
    useState<LocationSource>("city");

  function handleCitySelect(city: City) {
    selectCity(city);
    setLocationSource("city");
  }

  function handleLocationLocated(
    location: CurrentLocation,
  ) {
    setCurrentLocation(location);
    setLocationSource("browser");
  }

  const activeLocation =
    locationSource === "browser"
      ? currentLocation
      : selectedCity;

  const activeLocationLabel =
    locationSource === "browser"
      ? t("location.current")
      : selectedCity?.name ?? null;

  return (
    <main className="min-h-screen bg-background px-6 py-8 text-foreground">
      <section className="mx-auto max-w-5xl">
        <header className="flex justify-end gap-3">
          <LanguageSwitcher />
          <ThemeSwitcher />
        </header>

        <div className="mt-8 rounded-2xl border border-border bg-surface p-8 shadow-sm">
          <h1 className="text-4xl font-bold">
            {t("home.title")}
          </h1>

          <p className="mt-3 text-muted-foreground">
            {t("home.description")}
          </p>

          <div className="mt-6">
            <CitySearch
              onCitySelect={handleCitySelect}
            />
          </div>

          <div className="mt-3">
            <LocateUserButton
              onLocationLocated={
                handleLocationLocated
              }
            />
          </div>
        </div>

        <div className="mt-8">
          <WeatherOverview
            location={activeLocation}
            locationLabel={activeLocationLabel}
          />
        </div>
      </section>
    </main>
  );
}