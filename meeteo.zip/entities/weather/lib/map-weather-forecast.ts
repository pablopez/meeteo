import type { OpenMeteoForecastResponseDto } from "../api/open-meteo-forecast.types";
import { createDailyForecast } from "../model/daily-forecast";
import {
  createWeatherForecast,
  type WeatherForecast,
} from "../model/weather-forecast";

const MAX_FORECAST_DAYS = 15;

function readNumber(
  values: Array<number | null>,
  index: number,
): number {
  const value = values[index];

  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new Error("Invalid weather forecast response");
  }

  return value;
}

export function mapWeatherForecast(
  response: OpenMeteoForecastResponseDto,
): WeatherForecast {
  const daily = response.daily;

  if (
    typeof response.timezone !== "string" ||
    !daily ||
    !Array.isArray(daily.time) ||
    !Array.isArray(daily.weather_code) ||
    !Array.isArray(daily.temperature_2m_max) ||
    !Array.isArray(daily.temperature_2m_min) ||
    !Array.isArray(daily.precipitation_sum) ||
    !Array.isArray(daily.precipitation_probability_max)
  ) {
    throw new Error("Invalid weather forecast response");
  }

  const days = daily.time
    .slice(0, MAX_FORECAST_DAYS)
    .map((date, index) =>
      createDailyForecast({
        date,
        minimumTemperature: readNumber(
          daily.temperature_2m_min!,
          index,
        ),
        maximumTemperature: readNumber(
          daily.temperature_2m_max!,
          index,
        ),
        precipitationProbability: readNumber(
          daily.precipitation_probability_max!,
          index,
        ),
        precipitationAmount: readNumber(
          daily.precipitation_sum!,
          index,
        ),
        weatherCode: readNumber(
          daily.weather_code!,
          index,
        ),
      }),
    );

  return createWeatherForecast({
    timezone: response.timezone,
    days,
  });
}