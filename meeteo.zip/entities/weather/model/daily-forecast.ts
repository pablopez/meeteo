import {
  createPrecipitation,
  type Precipitation,
} from "./precipitation";
import {
  createTemperature,
  type Temperature,
} from "./temperature";

export type DailyForecast = {
  readonly date: string;
  readonly temperature: {
    readonly minimum: Temperature | null;
    readonly maximum: Temperature | null;
  };
  readonly precipitation: Precipitation;
  readonly weatherCode: number | null;
};

export type CreateDailyForecastInput = {
  readonly date: string;
  readonly minimumTemperature: number | null;
  readonly maximumTemperature: number | null;
  readonly precipitationProbability: number | null;
  readonly precipitationAmount: number | null;
  readonly weatherCode: number | null;
};

function isValidIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }

  const date = new Date(`${value}T00:00:00Z`);

  return (
    !Number.isNaN(date.getTime()) &&
    date.toISOString().startsWith(value)
  );
}

export function createDailyForecast({
  date,
  minimumTemperature,
  maximumTemperature,
  precipitationProbability,
  precipitationAmount,
  weatherCode,
}: CreateDailyForecastInput): DailyForecast {
  if (!isValidIsoDate(date)) {
    throw new Error("Invalid forecast date");
  }

  if (
  minimumTemperature !== null &&
  maximumTemperature !== null &&
  minimumTemperature > maximumTemperature
) {
  throw new Error(
    "Minimum temperature cannot exceed maximum temperature",
  );
}

  if (weatherCode !== null && (!Number.isInteger(weatherCode) || weatherCode < 0)) {
    throw new Error("Invalid weather code");
  }

  return {
    date,
     temperature: {
      minimum:
        minimumTemperature === null
          ? null
          : createTemperature(minimumTemperature),

      maximum:
        maximumTemperature === null
          ? null
          : createTemperature(maximumTemperature),
    },
    precipitation: createPrecipitation(
      precipitationProbability,
      precipitationAmount,
    ),
    weatherCode,
  };
}