export type Precipitation = {
  readonly probability: number | null;
  readonly amount: number | null;
  readonly unit: "millimeter";
};

export function createPrecipitation(
  probability: number | null,
  amount: number | null,
): Precipitation {
  if (
    probability !== null &&
    (!Number.isFinite(probability) ||
      probability < 0 ||
      probability > 100)
  ) {
    throw new Error("Invalid precipitation probability");
  }

  if (
    amount !== null &&
    (!Number.isFinite(amount) || amount < 0)
  ) {
    throw new Error("Invalid precipitation amount");
  }

  return {
    probability,
    amount,
    unit: "millimeter",
  };
}