import "@testing-library/jest-dom";

import { i18n } from "@/shared/config/i18n";

beforeEach(async () => {
  window.localStorage.clear();
  document.documentElement.lang = "en";

  await i18n.changeLanguage("en");
});