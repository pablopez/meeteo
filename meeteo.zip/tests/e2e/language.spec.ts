import { expect, test } from "@playwright/test";

test.describe("language preference", () => {
  test("changes and persists the selected language", async ({ page }) => {
    await page.goto("/");

    // Fijamos un estado inicial conocido.
    await page.evaluate(() => {
      window.localStorage.setItem("meeteo:language", "en");
    });

    await page.reload();

    const languageSelector = page.locator("#language-switcher");

    await expect(languageSelector).toHaveValue("en");

    await languageSelector.selectOption("es");

    await expect(languageSelector).toHaveValue("es");

    await expect(
      page.getByText(
"Información meteorológica de localidades de todo el mundo."      ),
    ).toBeVisible();

    await expect(page.locator("html")).toHaveAttribute("lang", "es");

    await page.reload();

    await expect(languageSelector).toHaveValue("es");
    await expect(page.locator("html")).toHaveAttribute("lang", "es");
  });
});