import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import { LanguageSwitcher } from "@/features/change-language";

describe("LanguageSwitcher", () => {
  it("changes and persists the selected language", async () => {
    const user = userEvent.setup();

    render(<LanguageSwitcher />);

    const selector = screen.getByRole("combobox", {
      name: "Language",
    });

    await user.selectOptions(selector, "es");

    expect(
      await screen.findByRole("combobox", {
        name: "Idioma",
      }),
    ).toHaveValue("es");

    expect(window.localStorage.getItem("meeteo:language")).toBe("es");
    expect(document.documentElement).toHaveAttribute("lang", "es");
  });

  it("restores the stored language", async () => {
    window.localStorage.setItem("meeteo:language", "es");

    render(<LanguageSwitcher />);

    expect(
      await screen.findByRole("combobox", {
        name: "Idioma",
      }),
    ).toHaveValue("es");
  });
});