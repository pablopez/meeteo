import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import { ThemeSwitcher } from "@/features/change-theme";

describe("ThemeSwitcher", () => {
  beforeEach(() => {
    localStorage.clear();
    document.documentElement.removeAttribute("data-theme");
  });

  it("changes the document theme", async () => {
    const user = userEvent.setup();

    render(<ThemeSwitcher />);

    const selector = screen.getByRole("combobox", {
      name: "Theme",
    });

    await user.selectOptions(selector, "dark");

    expect(selector).toHaveValue("dark");
    expect(document.documentElement).toHaveAttribute(
      "data-theme",
      "dark",
    );
  });

  it("restores the saved theme when mounted again", async () => {
    const user = userEvent.setup();

    const firstRender = render(<ThemeSwitcher />);

    await user.selectOptions(
      screen.getByRole("combobox", { name: "Theme" }),
      "dark",
    );

    firstRender.unmount();
    document.documentElement.removeAttribute("data-theme");

    render(<ThemeSwitcher />);

    await waitFor(() => {
      expect(
        screen.getByRole("combobox", { name: "Theme" }),
      ).toHaveValue("dark");
    });

    expect(document.documentElement).toHaveAttribute(
      "data-theme",
      "dark",
    );
  });
});