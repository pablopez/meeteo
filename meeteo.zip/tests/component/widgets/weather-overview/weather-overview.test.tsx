import {
  render,
  screen,
  within,
} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  getWeatherForecast,
  type WeatherForecast,
} from "@/entities/weather";
import {
  getEnvironmentForecast,
  type EnvironmentForecast,
} from "@/entities/environment";
import type { City } from "@/entities/city";
import { WeatherOverview } from "@/widgets/weather-overview";

jest.mock("@/entities/weather", () => ({
  getWeatherForecast: jest.fn(),
}));

jest.mock("@/entities/environment", () => ({
  ...jest.requireActual("@/entities/environment"),
  getEnvironmentForecast: jest.fn(),
}));

const mockedGetWeatherForecast =
  jest.mocked(getWeatherForecast);

const mockedGetEnvironmentForecast =
  jest.mocked(getEnvironmentForecast);

describe("WeatherOverview", () => {
  const madrid: City = {
    id: "3117735",
    name: "Madrid",
    countryCode: "ES",
    region: "Comunidad de Madrid",
    coordinates: {
      latitude: 40.4165,
      longitude: -3.7026,
    },
    isFavorite: false,
  };

  const forecast: WeatherForecast = {
    timezone: "Europe/Madrid",
    days: [
      {
        date: "2026-09-04",
        temperature: {
          minimum: {
            value: 16,
            unit: "celsius",
          },
          maximum: {
            value: 28,
            unit: "celsius",
          },
        },
        precipitation: {
          probability: 35,
          amount: 1.5,
          unit: "millimeter",
        },
        weatherCode: 61,
      },
      {
        date: "2026-09-05",
        temperature: {
          minimum: {
            value: 14,
            unit: "celsius",
          },
          maximum: {
            value: 24,
            unit: "celsius",
          },
        },
        precipitation: {
          probability: 75,
          amount: 3.5,
          unit: "millimeter",
        },
        weatherCode: 61,
      },
    ],
  };

  const environmentForecast: EnvironmentForecast = {
    timezone: "Europe/Madrid",
    days: [
      {
        date: "2026-09-04",
        airQuality: {
          europeanIndex: 35,
          level: "fair",
        },
        allergyMeasurements: [
          {
            allergen: "olive",
            concentration: 12,
            unit: "grains/m³",
          },
        ],
      },
    ],
  };

  beforeEach(() => {
    mockedGetWeatherForecast.mockReset();
    mockedGetEnvironmentForecast.mockReset();
  });

  it("shows the first forecast day", async () => {
    mockedGetWeatherForecast.mockResolvedValue(forecast);
    mockedGetEnvironmentForecast.mockResolvedValue(
      environmentForecast,
    );

    render(
      <WeatherOverview
        location={madrid}
        locationLabel={madrid.name}
      />,
    );

    expect(
      screen.getByText("Loading weather forecast..."),
    ).toBeInTheDocument();

    expect(
      await screen.findByRole("heading", {
        name: "Weather in Madrid",
      }),
    ).toBeInTheDocument();

    expect(screen.getByText("16 °C")).toBeInTheDocument();
    expect(screen.getByText("28 °C")).toBeInTheDocument();
    expect(screen.getByText("35%")).toBeInTheDocument();
    expect(screen.getByText("1.5 mm")).toBeInTheDocument();
  });

  it("shows an error when the weather request fails", async () => {
    mockedGetWeatherForecast.mockRejectedValue(
      new Error("Network error"),
    );
    mockedGetEnvironmentForecast.mockRejectedValue(
      new Error("Network error"),
    );

    render(
      <WeatherOverview
        location={madrid}
        locationLabel={madrid.name}
      />,
    );

    expect(
      await screen.findByRole("alert"),
    ).toHaveTextContent(
      "The weather forecast could not be loaded.",
    );
  });

  it("shows weather even when the environment request fails", async () => {
    mockedGetWeatherForecast.mockResolvedValue(forecast);
    mockedGetEnvironmentForecast.mockRejectedValue(
      new Error("Environment error"),
    );

    render(
      <WeatherOverview
        location={madrid}
        locationLabel={madrid.name}
      />,
    );

    expect(
      await screen.findByRole("heading", {
        name: "Weather in Madrid",
      }),
    ).toBeInTheDocument();

    expect(screen.getByText("16 °C")).toBeInTheDocument();
    expect(screen.getByText("28 °C")).toBeInTheDocument();
  });

  it("switches from carousel to table view", async () => {
    const user = userEvent.setup();

    mockedGetWeatherForecast.mockResolvedValue(forecast);
    mockedGetEnvironmentForecast.mockResolvedValue(
      environmentForecast,
    );

    render(
      <WeatherOverview
        location={madrid}
        locationLabel={madrid.name}
      />,
    );

    await screen.findByRole("heading", {
      name: "Weather in Madrid",
    });

    const tableButton = screen.getByRole("button", {
      name: "Table",
    });

    await user.click(tableButton);

    expect(tableButton).toHaveAttribute(
      "aria-pressed",
      "true",
    );

    const table = screen.getByRole("table", {
      name: "15-day weather forecast",
    });

    expect(
      within(table).getByText("16 °C"),
    ).toBeInTheDocument();

    expect(
      within(table).getByText("14 °C"),
    ).toBeInTheDocument();

    expect(
      within(table).getByText("75%"),
    ).toBeInTheDocument();

    expect(
      within(table).getByText("3.5 mm"),
    ).toBeInTheDocument();
  });

  it("shows environment data in the table for matching dates", async () => {
    const user = userEvent.setup();

    mockedGetWeatherForecast.mockResolvedValue(forecast);
    mockedGetEnvironmentForecast.mockResolvedValue(
      environmentForecast,
    );

    render(
      <WeatherOverview
        location={madrid}
        locationLabel={madrid.name}
      />,
    );

    await screen.findByRole("heading", {
      name: "Weather in Madrid",
    });

    await user.click(
      screen.getByRole("button", { name: "Table" }),
    );

    const table = screen.getByRole("table");

    expect(
      within(table).getByText("35"),
    ).toBeInTheDocument();

    expect(
      within(table).getByText("Fair"),
    ).toBeInTheDocument();

    expect(
      within(table).getAllByText("N/A").length,
    ).toBeGreaterThanOrEqual(1);
  });
});