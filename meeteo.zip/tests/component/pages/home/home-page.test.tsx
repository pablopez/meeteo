import { render, screen } from "@testing-library/react";

import { HomePage } from "@/views/home";
import userEvent from "@testing-library/user-event";

describe("HomePage", () => {
  it("renders the application title", () => {
    render(<HomePage />);

    expect(
      screen.getByRole("heading", {
        level: 1,
        name: "Meeteo",
      }),
    ).toBeInTheDocument();
  });
  it("translates the page into Spanish", async () => {
    const user = userEvent.setup();

    render(<HomePage />);

    await user.selectOptions(
      screen.getByRole("combobox", {
        name: "Language",
      }),
      "es",
    );

    expect(
      await screen.findByText(
"Información meteorológica de localidades de todo el mundo."      ),
    ).toBeInTheDocument();
  });
});