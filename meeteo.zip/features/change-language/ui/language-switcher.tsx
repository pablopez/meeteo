"use client";

import { useEffect, type ChangeEvent } from "react";
import { useTranslation } from "react-i18next";

import {
  getPreferredLanguage,
  saveLanguage,
} from "../lib/language-preference";
import { isLanguage } from "../model/language";

export function LanguageSwitcher() {
  const { t, i18n } = useTranslation();

  const resolvedLanguage =
    i18n.resolvedLanguage?.split("-")[0] ??
    i18n.language?.split("-")[0];

  const currentLanguage = isLanguage(resolvedLanguage)
    ? resolvedLanguage
    : "en";

  useEffect(() => {
    const preferredLanguage = getPreferredLanguage();

    document.documentElement.lang = preferredLanguage;
    void i18n.changeLanguage(preferredLanguage);
  }, [i18n]);

  function handleChange(event: ChangeEvent<HTMLSelectElement>) {
    const selectedLanguage = event.target.value;

    if (!isLanguage(selectedLanguage)) {
      return;
    }

    saveLanguage(selectedLanguage);
    document.documentElement.lang = selectedLanguage;
    void i18n.changeLanguage(selectedLanguage);
  }

  return (
    <label
      htmlFor="language-switcher"
      className="flex items-center gap-2"
    >
      <span className="text-sm text-muted-foreground">
        {t("language.label")}
      </span>

      <select
        id="language-switcher"
        value={currentLanguage}
        onChange={handleChange}
        className="rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground"
      >
        <option value="en">{t("language.english")}</option>
        <option value="es">{t("language.spanish")}</option>
      </select>
    </label>
  );
}