"use client";

import { useTranslation } from "react-i18next";

import type { City } from "@/entities/city";

import { useCitySearch } from "../model/use-city-search";

type CitySearchProps = {
  onCitySelect: (city: City) => void;
};

export function CitySearch({
  onCitySelect,
}: CitySearchProps) {
  const { t, i18n } = useTranslation();

  const {
    query,
    cities,
    status,
    updateQuery,
    clearResults,
  } = useCitySearch(i18n.resolvedLanguage ?? "en");

  function handleCitySelect(city: City) {
    clearResults();
    onCitySelect(city);
  }

  return (
    <section className="relative">
      <label
        htmlFor="city-search"
        className="mb-2 block text-sm font-medium"
      >
        {t("citySearch.label")}
      </label>

      <input
        id="city-search"
        type="search"
        value={query}
        placeholder={t("citySearch.placeholder")}
        autoComplete="off"
        onChange={(event) => updateQuery(event.target.value)}
        className="w-full rounded-xl border border-border bg-surface px-4 py-3 text-foreground outline-none focus:border-primary"
      />

      {status === "loading" && (
        <p role="status" className="mt-2 text-sm text-muted-foreground">
          {t("citySearch.loading")}
        </p>
      )}

      {status === "error" && (
        <p role="alert" className="mt-2 text-sm text-danger">
          {t("citySearch.error")}
        </p>
      )}

      {status === "success" && cities.length === 0 && (
        <p className="mt-2 text-sm text-muted-foreground">
          {t("citySearch.noResults")}
        </p>
      )}

      {cities.length > 0 && (
        <ul
          aria-label={t("citySearch.results")}
          className="absolute z-10 mt-2 w-full overflow-hidden rounded-xl border border-border bg-surface shadow-lg"
        >
          {cities.map((city) => (
            <li key={city.id}>
              <button
                type="button"
                onClick={() => handleCitySelect(city)}
                className="flex w-full justify-between px-4 py-3 text-left hover:bg-surface-muted"
              >
                <span className="font-medium">{city.name}</span>

                {city.region && (
                  <span className="text-sm text-muted-foreground">
                    {city.region && `${city.region}, `}
                    {city.countryCode}
                  </span>
                )}
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}