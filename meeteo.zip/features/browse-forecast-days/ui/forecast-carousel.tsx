"use client";

import { useTranslation } from "react-i18next";

import type { DailyEnvironmentalConditions } from "@/entities/environment";
import { formatWeatherMeasurement, type DailyForecast } from "@/entities/weather";

import { useForecastNavigation } from "../model/use-forecast-navigation";

type ForecastDayView = {
  weather: DailyForecast;
  environment: DailyEnvironmentalConditions | null;
};

type ForecastCarouselProps = {
  days: readonly ForecastDayView[];
};

export function ForecastCarousel({
  days,
}: ForecastCarouselProps) {
  const { t, i18n } = useTranslation();

  const {
    currentIndex,
    hasPreviousDay,
    hasNextDay,
    showPreviousDay,
    showNextDay,
  } = useForecastNavigation(days.length);

  const currentDay = days[currentIndex];

  if (!currentDay) {
    return null;
  }

  const { weather, environment } = currentDay;
  const locale = i18n.resolvedLanguage ?? "en";

  const formattedDate = new Intl.DateTimeFormat(locale, {
    weekday: "long",
    day: "numeric",
    month: "long",
    timeZone: "UTC",
  }).format(new Date(`${weather.date}T00:00:00Z`));

  const formatNumber = (value: number) =>
    new Intl.NumberFormat(locale, {
      maximumFractionDigits: 1,
    }).format(value);

  const unavailable = t("environment.unavailable");

  return (
    <section
      aria-label={t("forecastNavigation.label")}
      aria-roledescription="carousel"
    >
      <article
        aria-live="polite"
        className="mt-6"
      >
        <h3 className="text-lg font-semibold">
          {formattedDate}
        </h3>

        <dl className="mt-4 grid grid-cols-2 gap-4">
          <div className="rounded-xl bg-surface-muted p-4">
            <dt className="text-sm text-muted-foreground">
              {t("weather.minimum")}
            </dt>
            <dd className="mt-1 text-2xl font-semibold">
              {formatWeatherMeasurement(
                weather.temperature.minimum?.value ?? null,
                "celsius",
                locale,
                unavailable,
              )}
            </dd>
          </div>

          <div className="rounded-xl bg-surface-muted p-4">
            <dt className="text-sm text-muted-foreground">
              {t("weather.maximum")}
            </dt>
            <dd className="mt-1 text-2xl font-semibold">
              {formatWeatherMeasurement(
                weather.temperature.maximum?.value ?? null,
                "celsius",
                locale,
                unavailable,
              )}
            </dd>
          </div>

          <div className="rounded-xl bg-surface-muted p-4">
            <dt className="text-sm text-muted-foreground">
              {t("weather.rainProbability")}
            </dt>
            <dd className="mt-1 text-2xl font-semibold">
              {formatWeatherMeasurement(
                weather.precipitation.probability,
                "percent",
                locale,
                unavailable,
              )}
            </dd>
          </div>

          <div className="rounded-xl bg-surface-muted p-4">
            <dt className="text-sm text-muted-foreground">
              {t("weather.precipitation")}
            </dt>
            <dd className="mt-1 text-2xl font-semibold">
              {formatWeatherMeasurement(
                weather.precipitation.amount,
                "millimeter",
                locale,
                unavailable,
              )}
            </dd>
          </div>

          <div className="rounded-xl bg-surface-muted p-4">
            <dt className="text-sm text-muted-foreground">
              {t("environment.airQuality.label")}
            </dt>
            <dd className="mt-1 text-2xl font-semibold">
              {environment?.airQuality
                ? formatNumber(
                    environment.airQuality.europeanIndex,
                  )
                : unavailable}
            </dd>
            {environment?.airQuality && (
              <dd className="mt-1 text-sm text-muted-foreground">
                {t(
                  `environment.airQuality.levels.${environment.airQuality.level}`,
                )}
              </dd>
            )}
          </div>

          <div className="rounded-xl bg-surface-muted p-4">
            <dt className="text-sm text-muted-foreground">
              {t("environment.allergies.label")}
            </dt>
            {environment &&
            environment.allergyMeasurements.length > 0 ? (
              <dd className="mt-1">
                <ul className="space-y-1 text-sm">
                  {environment.allergyMeasurements.map(
                    (measurement) => (
                      <li
                        key={measurement.allergen}
                        className="flex justify-between gap-2"
                      >
                        <span>
                          {t(
                            `environment.allergies.allergens.${measurement.allergen}`,
                          )}
                        </span>
                        <span className="font-semibold">
                          {formatNumber(
                            measurement.concentration,
                          )}{" "}
                          {measurement.unit}
                        </span>
                      </li>
                    ),
                  )}
                </ul>
              </dd>
            ) : (
              <dd className="mt-1 text-sm text-muted-foreground">
                {environment
                  ? t("environment.allergies.unavailable")
                  : unavailable}
              </dd>
            )}
          </div>
        </dl>
      </article>

      <div className="mt-6 flex items-center justify-between gap-4">
        <button
          type="button"
          disabled={!hasPreviousDay}
          onClick={showPreviousDay}
          className="rounded-lg border border-border px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-40"
        >
          {t("forecastNavigation.previous")}
        </button>

        <p className="text-sm text-muted-foreground">
          {t("forecastNavigation.counter", {
            current: currentIndex + 1,
            total: days.length,
          })}
        </p>

        <button
          type="button"
          disabled={!hasNextDay}
          onClick={showNextDay}
          className="rounded-lg border border-border px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-40"
        >
          {t("forecastNavigation.next")}
        </button>
      </div>
    </section>
  );
}