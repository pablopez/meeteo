"use client";

import { useTranslation } from "react-i18next";

import type { CurrentLocation } from "@/entities/location";

import { useLocateUser } from "../model/use-locate-user";

type LocateUserButtonProps = {
  onLocationLocated: (
    location: CurrentLocation,
  ) => void;
};

export function LocateUserButton({
  onLocationLocated,
}: LocateUserButtonProps) {
  const { t } = useTranslation();

  const { status, locateUser } = useLocateUser({
    onLocationLocated,
  });

  const isLoading = status === "loading";

  return (
    <div>
      <button
        type="button"
        disabled={isLoading}
        onClick={() => void locateUser()}
        className="rounded-lg border border-border bg-surface px-4 py-2 text-sm font-medium disabled:cursor-wait disabled:opacity-60"
      >
        {isLoading
          ? t("location.locating")
          : t("location.useCurrent")}
      </button>

      {status === "error" && (
        <p
          role="alert"
          className="mt-2 text-sm text-danger"
        >
          {t("location.error")}
        </p>
      )}
    </div>
  );
}