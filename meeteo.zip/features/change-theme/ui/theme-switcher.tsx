"use client";

import { useEffect, useRef, type ChangeEvent } from "react";
import { useTranslation } from "react-i18next";

import {
  applyTheme,
  getStoredTheme,
  saveTheme,
} from "../lib/theme-preference";
import { isTheme } from "../model/theme";

export function ThemeSwitcher() {
  const selectRef = useRef<HTMLSelectElement>(null);
  const { t } = useTranslation();
  

  useEffect(() => {
    const storedTheme = getStoredTheme();

    applyTheme(storedTheme);

    if (selectRef.current) {
      selectRef.current.value = storedTheme;
    }
  }, []);

  function handleChange(event: ChangeEvent<HTMLSelectElement>) {
    const selectedTheme = event.target.value;

    if (!isTheme(selectedTheme)) {
      return;
    }

    saveTheme(selectedTheme);
    applyTheme(selectedTheme);
  }

  return (
    <label className="flex items-center gap-2 text-sm">
      <span className="text-sm text-muted-foreground">
  {t("theme.label")}
      </span>

      <select
        ref={selectRef}
        defaultValue="system"
        onChange={handleChange}
        className="rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground"
      >
        <option value="system">{t("theme.system")}</option>
        <option value="light">{t("theme.light")}</option>
        <option value="dark">{t("theme.dark")}</option>
      </select>
    </label>
  );
}