"use client";

import { useMemo, useState } from "react";
import { Trans, useTranslation } from "react-i18next";

import type { DailyEnvironmentalConditions } from "@/entities/environment";
import type { Location } from "@/entities/location";
import type { DailyForecast } from "@/entities/weather";
import { ForecastCarousel } from "@/features/browse-forecast-days";
import {
  ForecastViewSwitcher,
  type ForecastView,
} from "@/features/change-forecast-view";

import type { ForecastDayView } from "../model/forecast-day-view";
import { useEnvironmentForecast } from "../model/use-environment-forecast";
import { useWeatherForecast } from "../model/use-weather-forecast";
import { ForecastTable } from "./forecast-table";

type WeatherOverviewProps = {
  location: Location | null;
  locationLabel: string | null;
};

function composeForecastDays(
  weatherDays: readonly DailyForecast[],
  environmentDays: readonly DailyEnvironmentalConditions[] | null,
): ForecastDayView[] {
  const environmentByDate = new Map<
    string,
    DailyEnvironmentalConditions
  >();

  if (environmentDays) {
    for (const day of environmentDays) {
      environmentByDate.set(day.date, day);
    }
  }

  return weatherDays.map((weather) => ({
    weather,
    environment:
      environmentByDate.get(weather.date) ?? null,
  }));
}

export function WeatherOverview({
  location,
  locationLabel,
}: WeatherOverviewProps) {
  const { t } = useTranslation();
  const [forecastView, setForecastView] =
    useState<ForecastView>("carousel");

  const { status: weatherStatus, forecast: weatherForecast } =
    useWeatherForecast(location);

  const {
    status: environmentStatus,
    forecast: environmentForecast,
  } = useEnvironmentForecast(location);

  const composedDays = useMemo(() => {
    if (!weatherForecast) {
      return [];
    }

    return composeForecastDays(
      weatherForecast.days,
      environmentForecast?.days ?? null,
    );
  }, [weatherForecast, environmentForecast]);

  if (weatherStatus === "idle") {
    return (
      <p className="text-sm text-muted-foreground">
        {t("weather.empty")}
      </p>
    );
  }

  if (weatherStatus === "loading") {
    return (
      <p
        role="status"
        className="text-sm text-muted-foreground"
      >
        {t("weather.loading")}
      </p>
    );
  }

  if (
    weatherStatus === "error" ||
    !weatherForecast ||
    !location ||
    !locationLabel
  ) {
    return (
      <p role="alert" className="text-sm text-danger">
        {t("weather.error")}
      </p>
    );
  }

  const locationKey = [
    location.id,
    location.coordinates.latitude,
    location.coordinates.longitude,
  ].join(":");

  return (
    <section
      aria-labelledby="weather-title"
      className="rounded-2xl border border-border bg-surface p-6 shadow-sm"
    >
      <h2
        id="weather-title"
        className="text-2xl font-bold"
      >
        {t("weather.title", {
          city: locationLabel,
        })}
      </h2>

      {environmentStatus === "loading" && (
        <p className="mt-2 text-xs text-muted-foreground">
          {t("environment.loading")}
        </p>
      )}

      {environmentStatus === "error" && (
        <p className="mt-2 text-xs text-danger">
          {t("environment.error")}
        </p>
      )}

      <div className="mt-4 flex justify-end">
        <ForecastViewSwitcher
          value={forecastView}
          onChange={setForecastView}
        />
      </div>

      {forecastView === "carousel" ? (
        <ForecastCarousel
          key={locationKey}
          days={composedDays}
        />
      ) : (
        <ForecastTable days={composedDays} />
      )}

      <p className="mt-6 text-xs text-muted-foreground">
        <Trans
          i18nKey="environment.attribution"
          components={{
            openMeteo: (
              <a
                href="https://open-meteo.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="underline"
              />
            ),
            cams: (
              <a
                href="https://atmosphere.copernicus.eu/"
                target="_blank"
                rel="noopener noreferrer"
                className="underline"
              />
            ),
          }}
        />
      </p>
    </section>
  );
}